=================================================
     SwissAirDry Modulare Installation
=================================================

Schnellstartanleitung:

1. Entpacken Sie dieses Archiv in ein Verzeichnis Ihrer Wahl:
   unzip swissairdry_modular_installation.zip -d /opt/swissairdry

2. Wechseln Sie in das Skriptverzeichnis:
   cd /opt/swissairdry/scripts

3. Starten Sie das Hauptinstallationsskript:
   ./install_swissairdry.sh

Das Skript führt Sie durch den gesamten Installationsprozess und
konfiguriert alle notwendigen Komponenten.

Detaillierte Informationen finden Sie in der Dokumentation im Verzeichnis 'docs'.

Bei Problemen konsultieren Sie bitte FAQ_UND_FEHLERBEHEBUNG.md im Verzeichnis 'docs'.

=================================================
