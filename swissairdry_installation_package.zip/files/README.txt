SwissAirDry-System Komponenten
==============================

Dieses Archiv enthält die folgenden Komponenten des SwissAirDry-Systems:

1. docker-base-api.zip: Die Haupt-API des Systems
2. swissairdry_admin_dashboard.zip: Das Admin-Dashboard und die CSV-Import-Funktionalität
3. docker-compose.yml: Die Docker-Konfigurationsdatei für das Gesamtsystem

Für Installationsanweisungen, siehe die INSTALLATIONSANLEITUNG.md im docs-Verzeichnis.
