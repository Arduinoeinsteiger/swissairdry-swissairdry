"""
SwissAirDry - API-Router

Dieses Paket enthält alle API-Router für das SwissAirDry-System.

@author Swiss Air Dry Team <info@swissairdry.com>
@copyright 2023-2025 Swiss Air Dry Team
"""